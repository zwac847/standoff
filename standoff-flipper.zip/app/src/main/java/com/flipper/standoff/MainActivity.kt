package com.flipper.standoff

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Row(val title: String, val sub: String, val color: Int, val btn: String, val act: () -> Unit)

class MainActivity : Activity() {

    private var mode = 0
    private lateinit var status: TextView
    private lateinit var list: ListView
    private val adapter = RowAdapter()
    private val ui = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            render()
            ui.postDelayed(this, 5000)
        }
    }

    private fun dp(i: Int): Int = (i * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#0A0D13"))
        root.setPadding(dp(12), dp(36), dp(12), dp(8))

        status = TextView(this)
        status.setTextColor(Color.parseColor("#9AA4B2"))
        status.textSize = 13f
        status.setPadding(0, 0, 0, dp(8))
        root.addView(status)

        val bar = LinearLayout(this)
        bar.addView(barBtn("Firsatlar") { mode = 0; render() })
        bar.addView(barBtn("Pozisyon") { mode = 1; render() })
        bar.addView(barBtn("Ayar") { settings() })
        bar.addView(barBtn("Teshis") { diag() })
        root.addView(bar)

        list = ListView(this)
        list.divider = ColorDrawable(Color.TRANSPARENT)
        list.dividerHeight = dp(8)
        list.adapter = adapter
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, FlipService::class.java))
    }

    override fun onResume() {
        super.onResume()
        ui.post(tick)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(tick)
    }

    private fun barBtn(t: String, f: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.textSize = 11f
        b.isAllCaps = false
        b.setOnClickListener { f() }
        b.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        return b
    }

    private fun render() {
        val fee = Store.fee(this)
        val last = Store.lastUpdate(this)
        val time = if (last == 0L) "-" else SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(last))
        status.text = "Son veri: " + time + "  |  " + Store.info(this)

        val rows = ArrayList<Row>()
        if (mode == 0) {
            val minNet = Store.minNet(this)
            val items = Store.flips(this).filter { it.netPct(fee) > 0 }.sortedByDescending { it.netPct(fee) }
            for (f in items) {
                val pct = f.netPct(fee)
                val color = if (pct >= minNet) Color.parseColor("#5BE584") else Color.parseColor("#9AA4B2")
                rows.add(
                    Row(
                        f.name,
                        "Su an " + Store.fmt(f.current) + " G  |  30g ort. " + Store.fmt(f.avg) + " G\n" +
                            "Indirim %" + Store.fmt(f.discountPct()) + "  |  Net kar %" + Store.fmt(pct) + " (komisyon sonrasi)",
                        color, "Aldim"
                    ) { confirmBuy(f) }
                )
            }
            if (rows.isEmpty()) rows.add(Row("Henuz firsat yok", "Veri gelince burada listelenecek. Gelmezse Teshis'e bas.", Color.GRAY, "") { })
        } else {
            for (p in Store.positions(this)) {
                val net = p.target * (1 - fee / 100.0) - p.buyPrice
                val remind = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date(p.remindAt))
                rows.add(
                    Row(
                        p.name,
                        "Alis " + Store.fmt(p.buyPrice) + " G -> hedef " + Store.fmt(p.target) + " G\n" +
                            "Beklenen net " + Store.fmt(net) + " G  |  hatirlatma " + remind,
                        Color.parseColor("#F2A65A"), "Sattim"
                    ) { sold(p) }
                )
            }
            if (rows.isEmpty()) rows.add(Row("Pozisyon yok", "Bir firsatta 'Aldim' deyince burada takip edilir.", Color.GRAY, "") { })
        }
        adapter.rows = rows
        adapter.notifyDataSetChanged()
    }

    private fun num(e: EditText): Double? = e.text.toString().replace(',', '.').trim().toDoubleOrNull()

    private fun field(v: String): EditText {
        val e = EditText(this)
        e.setText(v)
        e.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        return e
    }

    private fun label(t: String): TextView {
        val l = TextView(this)
        l.text = t
        l.setPadding(0, dp(8), 0, 0)
        return l
    }

    private fun column(vararg v: View): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        for (x in v) box.addView(x)
        return box
    }

    private fun confirmBuy(f: Flip) {
        val price = field(Store.fmt(f.current))
        val hours = field("24")
        AlertDialog.Builder(this)
            .setTitle(f.name)
            .setView(column(label("Aldigin fiyat (G)"), price, label("Kac saat sonra hatirlat"), hours))
            .setPositiveButton("Aldim") { _, _ ->
                val buy = num(price) ?: f.current
                val hr = num(hours) ?: 24.0
                val now = System.currentTimeMillis()
                val l = Store.positions(this)
                l.add(Position(f.name, buy, f.avg, now, now + (hr * 3600_000).toLong()))
                Store.savePositions(this, l)
                mode = 1
                render()
            }
            .setNegativeButton("Vazgec", null)
            .show()
    }

    private fun sold(p: Position) {
        val l = Store.positions(this)
        l.removeAll { it.name == p.name && it.boughtAt == p.boughtAt }
        Store.savePositions(this, l)
        render()
    }

    private fun settings() {
        val fee = field(Store.fmt(Store.fee(this)))
        val minNet = field(Store.fmt(Store.minNet(this)))
        val interval = field(Store.interval(this).toString())
        AlertDialog.Builder(this)
            .setTitle("Ayarlar")
            .setView(
                column(
                    label("Market komisyonu %"), fee,
                    label("Bildirim icin en az net kar %"), minNet,
                    label("Kontrol araligi (dakika, en az 5)"), interval
                )
            )
            .setPositiveButton("Kaydet") { _, _ ->
                val iv = (num(interval) ?: 20.0).toInt().coerceAtLeast(5)
                Store.saveSettings(this, num(fee) ?: 20.0, num(minNet) ?: 3.0, iv)
                startService(Intent(this, FlipService::class.java).setAction("REFRESH"))
            }
            .setNeutralButton("Pil ayari") { _, _ ->
                try {
                    startActivity(
                        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + packageName))
                    )
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
            }
            .setNegativeButton("Kapat", null)
            .show()
    }

    private fun diag() {
        val d = Store.dbg(this)
        AlertDialog.Builder(this)
            .setTitle("Teshis")
            .setMessage(if (d.isBlank()) "Henuz veri yok" else d)
            .setPositiveButton("Simdi yenile") { _, _ ->
                startService(Intent(this, FlipService::class.java).setAction("REFRESH"))
            }
            .setNegativeButton("Kapat", null)
            .show()
    }

    inner class RowAdapter : BaseAdapter() {
        var rows: List<Row> = emptyList()
        override fun getCount(): Int = rows.size
        override fun getItem(position: Int): Any = rows[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val r = rows[position]
            val box = LinearLayout(this@MainActivity)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(dp(12), dp(10), dp(12), dp(10))
            box.setBackgroundColor(Color.parseColor("#12161F"))

            val title = TextView(this@MainActivity)
            title.text = r.title
            title.textSize = 16f
            title.setTextColor(r.color)
            box.addView(title)

            val sub = TextView(this@MainActivity)
            sub.text = r.sub
            sub.textSize = 13f
            sub.setTextColor(Color.parseColor("#C5CCD6"))
            box.addView(sub)

            if (r.btn.isNotEmpty()) {
                val b = Button(this@MainActivity)
                b.text = r.btn
                b.isAllCaps = false
                b.setOnClickListener { r.act() }
                box.addView(b)
            }
            return box
        }
    }
}
