package com.flipper.standoff

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

data class Flip(val name: String, val current: Double, val avg: Double) {
    fun net(fee: Double): Double = avg * (1 - fee / 100.0) - current
    fun netPct(fee: Double): Double = if (current > 0) net(fee) / current * 100.0 else 0.0
    fun discountPct(): Double = if (avg > 0) (current - avg) / avg * 100.0 else 0.0
}

data class Position(
    val name: String,
    val buyPrice: Double,
    val target: Double,
    val boughtAt: Long,
    val remindAt: Long,
    var timeAlerted: Boolean = false,
    var priceAlerted: Boolean = false,
    var missing: Int = 0,
    var missingAlerted: Boolean = false
)

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("flipper", Context.MODE_PRIVATE)

    fun fmt(v: Double): String = String.format(Locale.US, "%.2f", v)

    // Sitede fiyatlar karisik yaziliyor: "93.00 G", "116,3 G", "5.999,0 G"
    fun parsePrice(raw: String): Double? {
        var s = raw.replace("G", "").replace("g", "").replace("\u00a0", "").replace(" ", "").trim()
        if (s.isEmpty()) return null
        val dots = s.count { it == '.' }
        val hasComma = s.contains(',')
        s = when {
            dots > 0 && hasComma -> s.replace(".", "").replace(",", ".")
            hasComma -> s.replace(",", ".")
            dots > 1 -> s.replace(".", "")
            dots == 1 -> {
                val before = s.substringBefore('.')
                val after = s.substringAfter('.')
                if (after.length == 3 && before.isNotEmpty() && before != "0") before + after else s
            }
            else -> s
        }
        return s.toDoubleOrNull()
    }

    fun parseRaw(arr: JSONArray): List<Flip> {
        val out = LinkedHashMap<String, Flip>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val n = o.optString("n")
            val c = parsePrice(o.optString("c"))
            val a = parsePrice(o.optString("a"))
            if (n.isNotBlank() && c != null && a != null && c > 0) out[n] = Flip(n, c, a)
        }
        return out.values.toList()
    }

    fun fee(c: Context): Double = sp(c).getFloat("fee", 20f).toDouble()
    fun minNet(c: Context): Double = sp(c).getFloat("minNet", 3f).toDouble()
    fun interval(c: Context): Int = sp(c).getInt("interval", 20)

    fun saveSettings(c: Context, fee: Double, minNet: Double, interval: Int) {
        sp(c).edit()
            .putFloat("fee", fee.toFloat())
            .putFloat("minNet", minNet.toFloat())
            .putInt("interval", interval)
            .apply()
    }

    fun lastUpdate(c: Context): Long = sp(c).getLong("last", 0L)
    fun info(c: Context): String = sp(c).getString("info", "bekleniyor") ?: "bekleniyor"
    fun setInfo(c: Context, s: String) { sp(c).edit().putString("info", s).apply() }
    fun dbg(c: Context): String = sp(c).getString("dbg", "") ?: ""
    fun setDbg(c: Context, s: String) { sp(c).edit().putString("dbg", s).apply() }

    fun saveFlips(c: Context, list: List<Flip>) {
        val arr = JSONArray()
        for (f in list) arr.put(JSONObject().put("n", f.name).put("c", f.current).put("a", f.avg))
        sp(c).edit().putString("flips", arr.toString()).putLong("last", System.currentTimeMillis()).apply()
    }

    fun flips(c: Context): List<Flip> {
        val arr = JSONArray(sp(c).getString("flips", "[]"))
        val out = ArrayList<Flip>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(Flip(o.getString("n"), o.getDouble("c"), o.getDouble("a")))
        }
        return out
    }

    fun notified(c: Context): MutableSet<String> {
        val s = sp(c).getStringSet("notified", emptySet()) ?: emptySet()
        return HashSet(s)
    }

    fun setNotified(c: Context, s: Set<String>) {
        sp(c).edit().putStringSet("notified", HashSet(s)).apply()
    }

    fun positions(c: Context): MutableList<Position> {
        val arr = JSONArray(sp(c).getString("pos", "[]"))
        val out = ArrayList<Position>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(
                Position(
                    o.getString("n"), o.getDouble("b"), o.getDouble("t"),
                    o.getLong("at"), o.getLong("rm"),
                    o.optBoolean("ta"), o.optBoolean("pa"),
                    o.optInt("ms"), o.optBoolean("ma")
                )
            )
        }
        return out
    }

    fun savePositions(c: Context, l: List<Position>) {
        val arr = JSONArray()
        for (p in l) {
            arr.put(
                JSONObject().put("n", p.name).put("b", p.buyPrice).put("t", p.target)
                    .put("at", p.boughtAt).put("rm", p.remindAt)
                    .put("ta", p.timeAlerted).put("pa", p.priceAlerted)
                    .put("ms", p.missing).put("ma", p.missingAlerted)
            )
        }
        sp(c).edit().putString("pos", arr.toString()).apply()
    }
}
