package com.flipper.standoff

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import org.json.JSONTokener

class FlipService : Service() {

    private lateinit var web: WebView
    private val h = Handler(Looper.getMainLooper())
    private var tries = 0

    private val loop = object : Runnable {
        override fun run() {
            refresh()
            h.postDelayed(this, Store.interval(this@FlipService) * 60_000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ongoing", "Calisiyor", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("alerts", "Flip uyarilari", NotificationManager.IMPORTANCE_HIGH))
        startForeground(1, build("ongoing", "Standoff Flipper", "Baslatiliyor...", false))
        setupWeb()
        h.post(loop)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "REFRESH") {
            h.removeCallbacks(loop)
            h.post(loop)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        try { web.destroy() } catch (e: Exception) { }
        super.onDestroy()
    }

    private fun setupWeb() {
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.layout(0, 0, 1080, 2000)
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                tries = 0
                h.postDelayed({ extract() }, 4000)
            }
        }
    }

    private fun refresh() {
        checkTime()
        Store.setInfo(this, "guncelleniyor...")
        web.clearCache(true)
        web.loadUrl("https://standoff2markettracker.com/")
    }

    private fun extract() {
        web.evaluateJavascript(JS) { res ->
            var rows: List<Flip> = emptyList()
            var dbg = ""
            try {
                val s = JSONTokener(res).nextValue() as? String
                if (s != null) {
                    val o = JSONObject(s)
                    rows = Store.parseRaw(o.getJSONArray("rows"))
                    dbg = o.optString("dbg")
                }
            } catch (e: Exception) {
                dbg = "hata: " + e.message
            }
            Store.setDbg(this, dbg)
            if (rows.isEmpty() && tries < 6) {
                tries++
                h.postDelayed({ extract() }, 3000)
            } else if (rows.isEmpty()) {
                Store.setInfo(this, "liste okunamadi (Teshis'e bak)")
                ongoing("Liste okunamadi")
            } else {
                handle(rows)
            }
        }
    }

    private fun handle(flips: List<Flip>) {
        val fee = Store.fee(this)
        val minNet = Store.minNet(this)
        Store.saveFlips(this, flips)

        val good = flips.filter { it.netPct(fee) >= minNet }.sortedByDescending { it.netPct(fee) }
        val seen = Store.notified(this)
        seen.retainAll(flips.map { it.name }.toSet())
        var sent = 0
        for (f in good) {
            if (seen.add(f.name) && sent < 3) {
                sent++
                alert(
                    f.name.hashCode(),
                    "Al: " + f.name,
                    "Su an " + Store.fmt(f.current) + " G, 30g ort. " + Store.fmt(f.avg) +
                        " G. Komisyon sonrasi net %" + Store.fmt(f.netPct(fee))
                )
            }
        }
        Store.setNotified(this, seen)

        val pos = Store.positions(this)
        val byName = flips.associateBy { it.name }
        for (p in pos) {
            val cur = byName[p.name]
            if (cur != null) {
                p.missing = 0
                if (!p.priceAlerted && cur.current >= p.target) {
                    p.priceAlerted = true
                    alert(
                        p.name.hashCode() + 1, "Sat: " + p.name,
                        "Fiyat " + Store.fmt(cur.current) + " G, hedef " + Store.fmt(p.target) + " G'ye ulasti."
                    )
                }
            } else {
                p.missing++
                if (p.missing >= 2 && !p.missingAlerted) {
                    p.missingAlerted = true
                    alert(
                        p.name.hashCode() + 2, "Listeden cikti: " + p.name,
                        "Artik firsat listesinde degil, fiyati toparlamis olabilir. Marketten kontrol et."
                    )
                }
            }
        }
        Store.savePositions(this, pos)

        Store.setInfo(this, flips.size.toString() + " esya, " + good.size + " uygun")
        ongoing(good.size.toString() + " uygun flip var")
    }

    private fun checkTime() {
        val pos = Store.positions(this)
        val now = System.currentTimeMillis()
        var changed = false
        for (p in pos) {
            if (!p.timeAlerted && now >= p.remindAt) {
                p.timeAlerted = true
                changed = true
                alert(
                    p.name.hashCode() + 3, "Satis zamani: " + p.name,
                    "Hatirlatma surem doldu. Hedef " + Store.fmt(p.target) + " G."
                )
            }
        }
        if (changed) Store.savePositions(this, pos)
    }

    private fun ongoing(text: String) {
        getSystemService(NotificationManager::class.java)
            .notify(1, build("ongoing", "Standoff Flipper", text, false))
    }

    private fun alert(id: Int, title: String, text: String) {
        getSystemService(NotificationManager::class.java).notify(id, build("alerts", title, text, true))
    }

    private fun build(ch: String, title: String, text: String, auto: Boolean): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, ch)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(auto)
            .build()
    }

    companion object {
        private val JS = """
(function(){
  function txt(e){return (e.innerText||'').replace(/ /g,' ').trim();}
  var isPrice=/^[0-9][0-9.,]*\s*G${'$'}/i;
  var isNum=/^[+\-−]?[0-9.,]+\s*%?${'$'}/;
  var rows=Array.prototype.slice.call(document.querySelectorAll('tr,[role=row]'));
  var out=[]; var seen={}; var sample=[];
  for(var i=0;i<rows.length;i++){
    var r=rows[i];
    var cells=Array.prototype.slice.call(r.querySelectorAll('td,[role=cell],[role=gridcell]'));
    if(cells.length<3){cells=Array.prototype.slice.call(r.children);}
    if(cells.length<3) continue;
    var t=cells.map(txt);
    var prices=[]; var name='';
    for(var j=0;j<t.length;j++){
      var s=t[j];
      if(isPrice.test(s)){prices.push(s);}
      else if(!name && /[A-Za-z]{2}/.test(s) && !isNum.test(s) && s.length<80){name=s.split('\n')[0].trim();}
    }
    if(sample.length<3) sample.push(txt(r).replace(/\s+/g,' ').slice(0,200));
    if(name && prices.length>=2 && !seen[name]){seen[name]=1;out.push({n:name,c:prices[0],a:prices[1]});}
  }
  if(out.length===0){
    var els=Array.prototype.slice.call(document.querySelectorAll('button,a,[role=tab],li,div,span'));
    for(var k=0;k<els.length;k++){
      var e=els[k]; var s2=txt(e).toUpperCase();
      if(s2.indexOf('FLIP FINDER')>=0 && s2.length<25 && e.children.length<4){e.click();break;}
    }
  }
  return JSON.stringify({rows:out,dbg:'satir='+rows.length+' okunan='+out.length+' | '+sample.join(' || ')});
})()
""".trimIndent()
    }
}
